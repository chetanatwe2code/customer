import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nursery_v2/utils/string_extensions.dart';
import 'package:nursery_v2/view/checkout/widget/payment_radio_group.dart';

import '../../controller/cart_controller.dart';
import '../../controller/home_controller.dart';
import '../../core/di/api_client.dart';
import '../../core/di/api_provider.dart';
import '../../core/routes.dart';
import '../../model/CartModel.dart';
import '../../utils/price_converter.dart';
import '../old/checkout/widget/address_radio_group.dart';
import '../widget/toast.dart';

class CheckoutSummary{
  double? totalMrpAmount;
  double? totalAmount;
  double? subTotalAmount;
  double? totalGst;
  double? totalCGST;
  double? totalsGST;
  double? totalDiscount;
  double? totalShipCharge;
  CheckoutSummary({this.totalMrpAmount=0,this.subTotalAmount=0,this.totalAmount=0,this.totalCGST=0.0,this.totalGst=0.0,this.totalsGST=0.0,this.totalDiscount=0.0,this.totalShipCharge=100.0}){
    totalAmount = totalAmount! + totalShipCharge!;
  }
}

class CheckoutLogic extends GetxController {
  final ApiClient apiClient;
  CheckoutLogic({required this.apiClient});

  final List<CartModel> _cartList = [];
  List<CartModel> get cartList => _cartList;

  CheckoutSummary? checkoutSummary;
  var cartPrice = 0.0.obs;

  bool notAvailable = false;
  String notAvailableIds = "";
  AddressModel? addressModel;
  bool orderPlaceProcess = false;
  PaymentMethod? mode;

  @override
  void onInit() {
    _cartList.addAll(Get.find<CartController>().cartList);
    cartPrice.value = Get.find<CartController>().cartPrice.value;
    checkoutSummary  = PriceConverter.getCartGstAndDiscountPrice(cartModel: _cartList);
    super.onInit();
    update();
  }

  void increaseQuantity({required int index }) async{
    print("Step:: A");
    CartModel cartModel = cartList[index];
    cartList[index].isIncrease = true;
    update();
    int quantity =((cartModel.cartProductQuantity??0)+1);
    await apiClient.putAPI(ApiProvider.updateCart,{
      "id": cartModel.id,"product_verient_id":cartModel.productVerientId,"product_id":cartModel.productId,"cart_product_quantity":quantity
    }).then((value) => {
      if(value.body['success']){
        cartPrice.value += cartModel.price ?? 0,
        cartList[index].cartProductQuantity = quantity,
        cartList[index].isIncrease = false,
        checkoutSummary  = PriceConverter.getCartGstAndDiscountPrice(cartModel: _cartList),
        update(),
        print("Step:: B"),
        Get.find<CartController>().getCart(),
        Get.find<HomeLogic>().getProductFromApi()
      }
    }).catchError((e){
      cartList[index].isIncrease = false;
      update();
    });
  }

  void decreaseQuantity({required int index }) async{
    CartModel cartModel = cartList[index];
    cartList[index].isDecrease = true;
    update();
    if((cartModel.cartProductQuantity??0) <= 1){
      await deleteCart(index: index);
      cartList[index].isDecrease = false;
      update();
      return;
    }
    int quantity =((cartModel.cartProductQuantity??0)-1);
    await apiClient.putAPI(ApiProvider.updateCart,{
      "id": cartModel.id,"product_verient_id":cartModel.productVerientId,"product_id":cartModel.productId,"cart_product_quantity":quantity
    }).then((value) => {
      cartPrice.value -= cartModel.price ?? 0,
      cartList[index].cartProductQuantity = quantity,
      cartList[index].isDecrease = false,
      checkoutSummary  = PriceConverter.getCartGstAndDiscountPrice(cartModel: _cartList),
      update(),
      Get.find<CartController>().getCart(),
      Get.find<HomeLogic>().getProductFromApi()
    }).catchError((e){
      cartList[index].isDecrease = false;
      update();
    });
  }

  deleteCart({required int index , bool fromView = true }) async{
    CartModel cartModel = cartList[index];
    if(fromView){
      cartList[index].isDeleting = true;
      update();
    }
    apiClient.putAPI(ApiProvider.deleteCart,{"product_id":cartModel.productId,"product_verient_id":cartModel.productVerientId,}).then((value) => {
      print("APK_DONE:: ${value.body}"),
      if(value.body['success']){
        if(cartList.length == 1){
          Get.find<HomeLogic>().getProductFromApi(),
          Get.find<HomeLogic>().decreaseCartCount(),
          Get.offAllNamed(rsBasePage)
        }else{
          cartPrice.value -= (cartModel.price ?? 0) * (cartModel.cartProductQuantity??1),
          cartList.removeAt(index),
          checkoutSummary  = PriceConverter.getCartGstAndDiscountPrice(cartModel: _cartList),
          update(),
          Get.find<HomeLogic>().decreaseCartCount(),
          Get.find<CartController>().getCart(),
          Get.find<HomeLogic>().getProductFromApi(),
        },
      }else{
        cartList[index].isDeleting = false,
        update(),
      },
    }).catchError((e){
      cartList[index].isDeleting = false;
      update();
    });
  }

  String paymentMethod = "razorpay";
  payNow(){
    orderPlace(transaction: {
      "amount" : checkoutSummary?.totalAmount,
      "payment_method" : paymentMethod,
      "transection_id" :"32".toTransactionId(),
      "is_payment_done" : "1"
    });
  }

  orderPlace({ dynamic transaction }) async{
    orderPlaceProcess = true;
    update();// getOrderBody(mode)
    apiClient.postAPI(ApiProvider.orderPlace, {
      "payment_detail" : transaction ??  {},
      "delivery_address" : {
        "first_name": addressModel?.name,
        "email": addressModel?.email,
        "phone_no": addressModel?.number,
        "image": addressModel?.image,
        "address" : addressModel?.address,
        "city" : addressModel?.city,
        "pincode" : addressModel?.pin,
        "user_lat" : addressModel?.lat,
        "user_log" : addressModel?.long,
      },
      "order" : getOrderBody(mode)
    }).then((value) => {
      if(value.body['status'] == 'ok'){
        Get.offAllNamed(rsBasePage),
        Get.toNamed(rsOrderHistoryPage),
        Get.find<HomeLogic>().updateWhenCheckOut(),
        Toast.show(title: "Order Placed",toastMessage: value.body['response']),
      }else{
        Toast.show(toastMessage: value.body['response'],isError: true),
      },
      orderPlaceProcess = false,
      update()
    }).catchError((e){
      orderPlaceProcess = false;
      update();
      Toast.show(toastMessage: "Something went wrong",isError: true);
    });
  }

  serviceAvailable(){
    notAvailableIds = "";
    notAvailable = false;
    Set<String> uniqueVendorIds = <String>{};
    for (int i = 0; i < cartList.length; i++) {
      String vendorId = "${cartList[i].vendorId ?? ""}";
      if (vendorId.isNotEmpty) {
        uniqueVendorIds.add(vendorId);
      }
    }
    String vendorIds = uniqueVendorIds.join(",");
    List<String> stringList = vendorIds.split(",");

    /// check now
    apiClient.postAPI(ApiProvider.checkAvailable, {"pin": addressModel?.pin,"vendor_id": stringList }).then((value) => {
      if(value.body['status'] == true && value.body['service_not_available'].isEmpty){
        notAvailable = false,
      }else{
        if(value.body['service_not_available'] != null){
          if(value.body['service_not_available'].isNotEmpty){
            notAvailableIds = value.body['service_not_available'].join(","),
          }
        }else{
          notAvailable = true,
        }
      }
    },onError: (e){
      notAvailable = true;
    }).whenComplete(() => {
      update(),
      if(!notAvailable && notAvailableIds.isEmpty){
        if(mode == PaymentMethod.cod){
          orderPlace(),
        }else if(mode == PaymentMethod.payNow){
          payNow(),
        }

      }
    });
    //;
  }

  setUnavailableService(String vendorIds){
    for (int i = 0; i < cartList.length; i++) {
      if (vendorIds.contains("${cartList[i].vendorId}")) {
        notAvailable = true;
      }
    }
    update();
  }

  getOrderBody(PaymentMethod? mode){
    List<Map<String, dynamic>> mapList = [];
    for(int i = 0; i < cartList.length;i++){
      CheckoutSummary checkoutSummary = PriceConverter.getCartGstAndDiscountPrice(cartModel: [cartList[i]]) as CheckoutSummary;
      mapList.add({
        "product_id": cartList[i].productId,
        "vendor_id": cartList[i].vendorId,
        "product_verient_id": cartList[i].productVerientId,
        "total_gst": checkoutSummary.totalGst,
        "total_cgst": checkoutSummary.totalCGST,
        "total_sgst": checkoutSummary.totalsGST,
        "total_discount": checkoutSummary.totalDiscount,
        "shipping_charges": 0,
        "invoice_id": 0,
        "payment_mode": mode == PaymentMethod.cod ? "cod" : paymentMethod,
        "payment_ref_id": "0",
        "discount_coupon": 0,
        "discount_coupon_value": 0,
        "total_amount": checkoutSummary.totalAmount,
        "total_of_this_prodoct": (cartList[i].price??0)*(cartList[i].cartProductQuantity??1),
        "total_order_product_quantity": cartList.length,
        "cart_qty_of_this_product": cartList[i].cartProductQuantity,
      });
    }
    return mapList;
  }

}
