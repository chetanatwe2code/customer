import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:nursery_v2/view/checkout/widget/payment_radio_group.dart';
import 'package:nursery_v2/view/widget/toast.dart';
import '../../../../controller/account_controller.dart';
import '../../../../theme/app_colors.dart';
import '../../widget/common_material_button.dart';
import '../../widget/input_field/common_input_field.dart';
import 'address_radio_group.dart';

class ConfirmOrder extends StatefulWidget {
  final Function(PaymentMethod mode,AddressModel addressModel)? callback;
  final double? paddingTop;
  const ConfirmOrder({Key? key,this.callback,this.paddingTop}) : super(key: key);

  @override
  State<ConfirmOrder> createState() => _ConfirmOrderState();
}

class _ConfirmOrderState extends State<ConfirmOrder> {

  PaymentMethod paymentMode = PaymentMethod.cod;
  AddressModel addressModel = AddressModel(
      name: Get.find<AccountLogic>().userModel?.firstName??"",
      email: Get.find<AccountLogic>().userModel?.email??"",
      number: Get.find<AccountLogic>().userModel?.phoneNo??"",
      image: Get.find<AccountLogic>().userModel?.image??"",
      address: Get.find<AccountLogic>().userModel?.address??"",
      city: Get.find<AccountLogic>().userModel?.city??"",
      pin: Get.find<AccountLogic>().userModel?.pincode??"",
  );

  @override
  void initState() {
    super.initState();
    nameController.text = addressModel.name??"";
    emailController.text = addressModel.email??"";
    numberController.text = addressModel.number??"";
  }

  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController numberController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.only(
              topRight: Radius.circular(10.r),
              topLeft: Radius.circular(10.r),
            ),
            color: AppColors.whiteColor()
        ),
        height: Get.height,
        padding: EdgeInsets.symmetric(horizontal: 10.r),
        // margin: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [

            SizedBox(height: widget.paddingTop,),

            /// Header
            SizedBox(
              height: kToolbarHeight,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("Delivery Address",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16.sp
                          ),),

                        InkWell(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(2.0),
                            child: Icon(
                              Icons.clear, color: AppColors.textColor(),),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            AddressRadioGroup(
              callback: (addressModel){
                setState(() {
                  this.addressModel = AddressModel(
                    city: addressModel.city,
                    pin: addressModel.pin,
                    address: addressModel.address,
                    email: this.addressModel.email,
                    image: this.addressModel.image,
                    lat: this.addressModel.lat,
                    long: this.addressModel.long,
                    name: this.addressModel.name,
                    number: this.addressModel.number
                  );
                });
              },
            ),

            Padding(
              padding: const EdgeInsets.only(top: 15,left: 12),
              child: CommonInputField(
                hintText: 'Name',
                labelText: "Name",
                onTextChanged: (str){
                  addressModel.name = str;
                },
                textController: nameController,
                keyboardType: TextInputType.name,
                suffixIcon: const Icon(Icons.person),
              ),
            ),

            Padding(
              padding: const EdgeInsets.only(top: 15,left: 12),
              child: CommonInputField(
                hintText: 'email',
                labelText: "email",
                onTextChanged: (str){
                  addressModel.email = str;
                },
                textController: emailController,
                keyboardType: TextInputType.emailAddress,
                suffixIcon: const Icon(Icons.email),
              ),
            ),

            Padding(
              padding: const EdgeInsets.only(top: 15,left: 12),
              child: CommonInputField(
                hintText: 'number',
                labelText: "number",
                onTextChanged: (str){
                  addressModel.number = str;
                },
                textController: numberController,
                keyboardType: TextInputType.phone,
                maxLength: 10,
                suffixIcon: const Icon(Icons.phone),
              ),
            ),

            /// Header
            SizedBox(
              height: kToolbarHeight,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("Payment Mode",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16.sp
                          ),),

                        // InkWell(
                        //   onTap: () {
                        //     Navigator.pop(context);
                        //   },
                        //   child: Padding(
                        //     padding: const EdgeInsets.all(2.0),
                        //     child: Icon(
                        //       Icons.clear, color: AppColors.textColor(),),
                        //   ),
                        // ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            PaymentRadioGroup(
              callback: (mode){
                setState((){
                  paymentMode = mode??PaymentMethod.cod;
                });
              },
              initialValue: PaymentMethod.cod,
            ),

            20.verticalSpace,

            CommonMaterialButton(
              text: "Proceed",
              color: AppColors.primary,
              fontColor: Colors.white,
              onTap: (){
                if(addressModel.address == null){
                  Toast.show(toastMessage: "Enter Address",isError: true);
                }else if(addressModel.city == null){
                  Toast.show(toastMessage: "Enter city",isError: true);
                }else if(addressModel.pin == null){
                  Toast.show(toastMessage: "Enter Pin-Code",isError: true);
                }else if(addressModel.pin?.length != 6){
                  Toast.show(toastMessage: "Enter Valid pin-code",isError: true);
                }else if(nameController.text.isEmpty){
                  Toast.show(toastMessage: "Enter Name",isError: true);
                }else if(emailController.text.isEmpty){
                  Toast.show(toastMessage: "Enter Email",isError: true);
                }else if(numberController.text.isEmpty){
                  Toast.show(toastMessage: "Enter Phone Number",isError: true);
                }else{
                  if(widget.callback != null){
                    widget.callback!(paymentMode,addressModel);
                  }
                }
              },
            ),

            20.verticalSpace,

          ],
        ),
      ),
    );
  }
}
