import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../theme/app_colors.dart';

enum PaymentMethod { cod,payNow }

class PaymentRadioGroup extends StatefulWidget {
  final PaymentMethod? initialValue;
  final Function(PaymentMethod? mode)? callback;
  const PaymentRadioGroup({Key? key,this.initialValue,this.callback}) : super(key: key);

  @override
  State<PaymentRadioGroup> createState() => _PaymentRadioGroupState();
}

class _PaymentRadioGroupState extends State<PaymentRadioGroup> {

  PaymentMethod? selected;
  int? id;

  @override
  void initState() {
    super.initState();
    if(widget.initialValue == PaymentMethod.cod){
      selected = PaymentMethod.cod;
      id = 1;
    }if(widget.initialValue == PaymentMethod.payNow){
      selected = PaymentMethod.payNow;
      id = 2;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[

        InkWell(
          onTap: (){
            selected = PaymentMethod.cod;
            id = 1;
            if(widget.callback != null){
              widget.callback!(selected!);
            }
            setState(() {});
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Radio(
                value: 1,
                groupValue: id,
                onChanged: (val) {
                  selected = PaymentMethod.cod;
                  id = 1;
                  if(widget.callback != null){
                    widget.callback!(selected!);
                  }
                  setState(() {});
                },
              ),
              Text(
                'Cash on delivery',
                style: TextStyle(
                    color: AppColors.blackColor(),
                    fontSize: 17.sp,
                    fontWeight: FontWeight.w500
                ),
              ),
            ],
          ),
        ),

        10.verticalSpace,

        InkWell(
          onTap: (){
            selected = PaymentMethod.payNow;
            id = 2;
            if(widget.callback != null){
              widget.callback!(selected!);
            }
            setState(() {});
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Radio(
                value: 2,
                groupValue: id,
                onChanged: (val) {
                  selected = PaymentMethod.payNow;
                  id = 2;
                  if(widget.callback != null){
                    widget.callback!(selected!);
                  }
                  setState(() {});
                },
              ),
              Text(
                'Pay Now',
                style: TextStyle(
                    color: AppColors.blackColor(),
                    fontSize: 17.sp,
                    fontWeight: FontWeight.w500
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
