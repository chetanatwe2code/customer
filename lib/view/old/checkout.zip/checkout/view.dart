import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../theme/app_colors.dart';
import '../old/checkout/widget/confirm_order.dart';
import '../widget/common_material_button.dart';
import '../widget/product/checkout_product_view.dart';
import '../widget/toast.dart';
import 'logic.dart';

class CheckoutPage extends StatelessWidget {
  const CheckoutPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    CheckoutLogic controller = Get.find();
    return Scaffold(
      appBar: AppBar(title: const Text("Checkout Cart")),
      bottomNavigationBar: Container(
        height: 50,
        margin: EdgeInsets.symmetric(horizontal: 10.r),
        child: GetBuilder<CheckoutLogic>(builder: (logic) {
          return Column(
            children: [
              if(logic.cartList.isNotEmpty)
                CommonMaterialButton(
                  color: AppColors.primaryColor(),
                  borderRadius: 5,
                  isEnable: !logic.notAvailable && logic.notAvailableIds.isEmpty,
                  isLoading: logic.orderPlaceProcess,
                  onTap: () {
                    Get.bottomSheet(
                      ConfirmOrder(callback: (mode, address) {
                        logic.addressModel = address;
                        logic.mode = mode;
                        Navigator.pop(context);
                        controller.serviceAvailable();
                      }, paddingTop: MediaQuery
                          .of(context)
                          .padding
                          .top),
                      isScrollControlled: true,
                      barrierColor: Colors.transparent,
                      isDismissible: false,
                    );
                  },
                  label: Row(
                    children: [
                      Text("Order now", style: TextStyle(
                        color: AppColors.whiteColor(),
                        fontSize: 14.sp,
                        letterSpacing: -0.4,
                        fontWeight: FontWeight.w400,
                      ),),
                      40.horizontalSpace,
                      Text("|", style: TextStyle(
                        color: AppColors.whiteColor(),
                        fontSize: 14.sp,
                        letterSpacing: -0.4,
                        fontWeight: FontWeight.w400,
                      ),),
                      20.horizontalSpace,
                      Text("\u{20B9}${logic.checkoutSummary!.totalAmount}", style: TextStyle(
                        color: AppColors.whiteColor(),
                        fontSize: 14.sp,
                        letterSpacing: -0.4,
                        fontWeight: FontWeight.w400,
                      ),),
                    ],
                  ),
                )
            ],
          );
        }),
      ),
      body: Padding(
        padding: EdgeInsets.only(left: 10.r,right: 10.r),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            /// cart
            Expanded(
              child: SingleChildScrollView(
                child: GetBuilder<CheckoutLogic>(
                  assignId: true,
                  builder: (logic) {
                    return ListView.builder(
                      itemCount: logic.cartList.length,
                      padding: EdgeInsets.symmetric(vertical: 10.r),
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemBuilder: (BuildContext context, int index) {
                        return CheckoutProductView(
                          cartModel: logic.cartList[index],
                          onIncrease: () {
                            logic.increaseQuantity(index: index);
                          },
                          onDecrease: () {
                            logic.decreaseQuantity(index: index);
                          },
                          deleteCart: () {
                            logic.deleteCart(index: index);
                          },
                        );
                      },
                    );
                  },
                ),
              ),
            ),

            /// order
            Divider(
              height: 0.5.r,
              thickness: 0.5.r,
              color: AppColors.grayColor().withOpacity(0.2),
            ),
            7.verticalSpace,
            Text("Order Summary",
              style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textColor()
              ),),
            7.verticalSpace,
            Divider(
              height: 0.5.r,
              thickness: 0.5.r,
              color: AppColors.grayColor().withOpacity(0.2),
            ),
            10.verticalSpace,
            GetBuilder<CheckoutLogic>(
              assignId: true,
              builder: (logic) {
                return Column(
                  children: [

                    if((logic.checkoutSummary?.totalMrpAmount ?? 0) > 0)
                      getSummaryRow(title: "Total Amount",
                          value: "${((controller.checkoutSummary!.totalMrpAmount??0))-(logic.checkoutSummary!.totalGst??0)}"),

                    if((logic.checkoutSummary?.totalGst ?? 0) > 0)
                      getSummaryRow(title: "Total Gst",
                          value: "+ ${controller.checkoutSummary!.totalGst}"),
                    //
                    // if((logic.checkoutSummary?.totalsGST ?? 0) > 0)
                    //   getSummaryRow(title: "Total S Gst",
                    //       value: "+ ${controller.checkoutSummary!.totalsGST}"),
                    //
                    // if((logic.checkoutSummary?.totalCGST ?? 0) > 0)
                    //   getSummaryRow(title: "Total C Gst",
                    //       value: "+ ${controller.checkoutSummary!.totalCGST}"),

                    if((logic.checkoutSummary?.totalDiscount ?? 0) > 0)
                      getSummaryRow(title: "Total Discount",
                          value: "- ${logic.checkoutSummary!.totalDiscount}"),

                    if((logic.checkoutSummary?.totalShipCharge ?? 0) > 0)
                      getSummaryRow(title: "Total Delivery Charge",
                          value: "${logic.checkoutSummary!.totalShipCharge}"),

                    Divider(
                      height: 0.5.r,
                      thickness: 0.5.r,
                      color: AppColors.grayColor().withOpacity(0.2),
                    ),

                    10.verticalSpace,
                    getSummaryRow(title: "Grand Total",
                        value: "${logic.checkoutSummary!.totalAmount}",
                        isTotalRow: true),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget getSummaryRow(
      { required String title, required String value, bool isTotalRow = false }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title,
            style: TextStyle(
                color: AppColors.textColor(),
                fontWeight: isTotalRow ? FontWeight.bold : null
            ),),

          Text(value,
            style: TextStyle(
                color: AppColors.textColor(),
                fontWeight: isTotalRow ? FontWeight.bold : null
            ),),

        ],),
    );
  }
}
